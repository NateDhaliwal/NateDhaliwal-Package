# NateDhaliwal-Package
This is a package that allows Python functions to be used better, with less lines of code.
<hr>

## Installation
To install this package, enter this command line:
`pip install natedhaliwal`