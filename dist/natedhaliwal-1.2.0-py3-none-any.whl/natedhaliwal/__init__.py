from natedhaliwal.example import *

display('Hello')